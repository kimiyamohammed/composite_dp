/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package compositepatterndemo;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author hanun
 */
public class Employee {
    private String name;
    private String dept;
    private int salary;
    private List<Employee> subordinates;
    private List<String> myBosses;
    private String boss;
    public Employee(String name, String dept, int sal){
        this.name = name;
        this.dept = dept;
        this.salary = sal;
        this.subordinates = new ArrayList<Employee>();
        this.myBosses = new ArrayList<String>();
        this.boss = null;

    }
   
    public String getName(){
        return this.name;
    }
    
    public String getDept(){
        return this.dept;
    }

    public int getSalary(){
        return this.salary;
    }
    
    public void add(Employee e){
        subordinates.add(e);
        e.myBosses.add(getName());
        e.boss = getName();
        if(boss != null){
            e.myBosses.add(boss);
        }
    }
  
    public void remove(Employee e){
        subordinates.remove(e);
        e.myBosses.remove(getName());
        e.boss = getName();
        if(boss != null){
            e.myBosses.remove(boss);
        }
    }
     
    public List<Employee> getSubordinates(){
        return subordinates;
    }
    
    public String toString(){
        return ("Employee:[Name: "+ name +", Dept: " + dept + ", Salary: " + salary + "]");
    }
    
    public List<String> getAllBosses(){
        return myBosses;
    }
    
    public int getTotalSalary(){
        int totalSalary = getSalary(); // The total salary is inclusive(i.e it contains the boss salary too)
        for(int i = 0; i < subordinates.size(); i++){
            if(!subordinates.isEmpty()){
                totalSalary += subordinates.get(i).getSalary();
                if(!subordinates.get(i).subordinates.isEmpty()){
                    for(int j = 0; j < subordinates.get(i).subordinates.size(); j++){
                        totalSalary += subordinates.get(i).subordinates.get(j).getSalary();
                    }
                }
            }
        }
        return totalSalary;
    }
    public void getLowerEmployee(){
        System.out.println(getDept() +" : "+ getName()); 
        for(int i = 0; i < subordinates.size(); i++){
            if(!subordinates.isEmpty()){
                System.out.println( subordinates.get(i).getDept() +" : "+ subordinates.get(i).getName());
                if(!subordinates.get(i).subordinates.isEmpty()){
                    for(int j = 0; j < subordinates.get(i).subordinates.size(); j++){
                        System.out.println(subordinates.get(i).subordinates.get(j).getDept() +" : "+ subordinates.get(i).getName());
                    }
                }
            }
        }
    }
}
